#/bin/sh

java -jar AgnssCaster-1.0.0-fat.jar -conf AgnssCaster.json
